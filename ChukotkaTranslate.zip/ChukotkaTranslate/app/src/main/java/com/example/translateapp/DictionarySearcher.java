package com.example.translateapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DictionarySearcher {

    private DatabaseHelper dbHelper;

    public DictionarySearcher(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public List<String> search(String query) {
        List<String> results = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME,
                new String[]{DatabaseHelper.COLUMN_TERM},
                DatabaseHelper.COLUMN_TERM + " LIKE ?",
                new String[]{"%" + query + "%"},
                null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                results.add(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TERM)));
            }
            cursor.close();
        }

        db.close();
        return results;
    }

    public String getDefinition(String term) {
        String definition = null;
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME,
                new String[]{DatabaseHelper.COLUMN_DEFINITION},
                DatabaseHelper.COLUMN_TERM + " = ?",
                new String[]{term},
                null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                definition = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DEFINITION));
            }
            cursor.close();
        }

        db.close();
        return definition;
    }
}

