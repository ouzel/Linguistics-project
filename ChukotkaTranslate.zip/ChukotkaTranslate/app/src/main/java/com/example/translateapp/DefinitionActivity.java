package com.example.translateapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DefinitionActivity extends AppCompatActivity {

    private TextView definitionTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_definition);

        definitionTextView = findViewById(R.id.definitionTextView);

        String definition = getIntent().getStringExtra("definition");
        definitionTextView.setText(definition);
    }
}

