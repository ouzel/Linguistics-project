package com.example.translateapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.util.Log;

import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public class CSVLoader {

    private DatabaseHelper dbHelper;
    private Context context;

    public CSVLoader(Context context) {
        this.context = context;
        dbHelper = new DatabaseHelper(context);
    }

    public void loadCSV() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            // CSVReader reader = new CSVReader(new InputStreamReader(context.getAssets().open("C:\\Users\\Sophie\\AndroidStudioProjects\\TranslateApp\\app\\src\\main\\res\\raw")));
            InputStream is = context.getResources().openRawResource(R.raw.dict);
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is, Charset.forName("UTF-8")));
            String nextLine;
            ContentValues values = new ContentValues();
            while ((nextLine = reader.readLine()) != null) {
                values.put(DatabaseHelper.COLUMN_TERM, nextLine.split(",")[3]);
                String defin = "(чук) " + nextLine.split(",")[0] + "\n\n" +
                        "(рус) " +  nextLine.split(",")[3] + "\n" +
                        "(анг) " +  nextLine.split(",")[2] + "\n" +
                        "(фра) " +  nextLine.split(",")[1] + "\n\n" +
                        "Примеры: " + "\n" +
                        "(чук) " + nextLine.split(",")[4] + "\n" +
                        "(рус) " + nextLine.split(",")[7] + "\n" +
                        "(анг) " + nextLine.split(",")[6] + "\n" +
                        "(фра) " + nextLine.split(",")[5];
                values.put(DatabaseHelper.COLUMN_DEFINITION, defin);
                db.insert(DatabaseHelper.TABLE_NAME, null, values);
            }
            reader.close();
        } catch (Exception e) {
            Log.e("CSVLoader", "Error loading CSV", e);
        } finally {
            db.close();
        }
    }
}

